import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nave-bar',
  templateUrl: './nave-bar.component.html',
  styleUrls: ['./nave-bar.component.css']
})
export class NaveBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
